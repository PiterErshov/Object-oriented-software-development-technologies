﻿#include <iostream>
#include "Worker.h"
#include <fstream>
#include <vector>
#include <list>

using namespace std;
using namespace Workers;

void file_load(list<Worker>& workers, string filename)
{
    Worker wr;
    ifstream f(filename);

    if (!f.is_open())
    {
        cout << "Error! No file with name " << filename << endl;
        return;
    }

    while (!f.eof())
    {
        f >> wr;
        if (f.fail())
        {
            f.clear(ios::eofbit);
            break;
        }
        workers.push_back(wr);
    }
    f.close();
};


void file_save(list<Worker> workers, string filename)
{
    Worker wr;
    ofstream f(filename);

    if (!f.is_open())
    {
        cout << "Error! No file with name " << filename << endl;
        return;
    }

    for (auto iter = workers.begin(); iter != workers.end(); iter++)
    {
        f << *iter << endl;
    }
    f.close();
};

void output_all(list<Worker> workers, int format)
{
    int i = 0;
    for (auto iter = workers.begin(); iter != workers.end(); iter++)
    {
        if (format == 1)
            cout << stand_out << i << ". " << *iter << endl;
        else
            cout << tab_out << i << ". " << *iter << endl;
        i++;
    }
}

list<Worker> search(list<Worker> workers, string function)
{
    list<Worker> out;
    list<Worker>::iterator iter;
    iter = find_if(workers.begin(), 
        workers.end(), 
        [&](Worker w)
        {
            return w.getFunc() == function;
        });

    while (iter != workers.end())
    {
        out.push_back(*iter);
        iter++;
        iter = find_if(iter, workers.end(), [&](Worker w)
            {
                return w.getFunc() == function;
            });
    }

    return out;
}

list<Worker> search(list<Worker> workers, int year)
{
    struct tm* date;
    time_t t = time(NULL);
    date = gmtime(&t);
    int tt = date->tm_year + 1900;
    list<Worker> out;
    list<Worker>::iterator iter;
    iter = find_if(workers.begin(),
        workers.end(),
        [&](Worker w)
        {
            return (tt - w.getYear()) > year;
        });

    while (iter != workers.end())
    {
        out.push_back(*iter);
        iter++;
        iter = find_if(workers.begin(),
            workers.end(),
            [&](Worker w)
            {
                return (tt - w.getYear()) > year;
            });
    }

    return out;
};

void sort(list<Worker>& workers, int num)
{
    if (num == 1)
        workers.sort([](Worker& a, Worker& b) { return a.getS_name() < b.getS_name(); });
    if (num == 2)
        workers.sort([](Worker& a, Worker& b) { return a.getYear() < b.getYear(); });
}

void mod(list<Worker>& workers, Worker buf, int num)
{
    auto w_i = workers.begin();
    advance(w_i, num);
    w_i->setS_name(buf.getS_name());
    w_i->setName(buf.getName());
    w_i->setPatr(buf.getPatr());
    w_i->setFunc(buf.getFunc());
    w_i->set_Date(buf.getDay(), buf.getMonth(), buf.getYear());
};

int main()
{
    setlocale(LC_ALL, "Russian");
   
    bool exit = false;
    int option;

    list<Worker> workers;

    while (!exit)
    {
        cout << "Выберете функцию:" << endl;
        cout << "1. Вывод списка рабочих." << endl;
        cout << "2. Добавление нового рабочего." << endl;
        cout << "3. Добавление рабочих из файла." << endl;
        cout << "4. Удаление рабочих." << endl;
        cout << "5. Поиск рабочих, чей стаж превышает заданное значение." << endl;
        cout << "6. Поиск рабочих по конкретной должности." << endl;
        cout << "7. Сохранение списка рабочих в указанный файл." << endl;
        cout << "8. Модификация указанной записи рабочего." << endl;
        cout << "9. Сортировка списка." << endl;
        cout << "10. Выход." << endl;

        cin >> option;

        while (cin.fail())
        {
            cin.clear();
            cout << "Не верное значение!" << endl;
            cin.ignore();
            cin >> option;
        }

        switch (option)
        {
        case 1:
        {
            int format;
            cout << "Выберите формат вывода:" << endl;
            cout << "1. Стандартный в строку." << endl;
            cout << "2. В формате таблицы." << endl;
            cin >> format;            
            if (!workers.empty())
                output_all(workers, format);
            else
                cout << "Список рабочих пуст" << endl;
            cout << endl;
            break;
        }
        case 2:
        {
            Worker buf;
            cout << "Введите данные нового рабочего в формате: Фамилия Имя Отчество Должность (0.0.0000)" << endl;
            cin >> buf;
            /*if (cin.fail())
                cout << "Ошибка. Неверный формат ввода." << endl;
            else*/
                workers.push_back(buf);
            cout << endl;
            break;
        }
        case 3:
        {
            file_load(workers, "data.txt");
            cout << endl;
            break;
        }
        case 4:
        {
            if (!workers.empty())
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }

            int num;
            cout << "Выберите номер рабочего, чья запись будет удалена:" << endl;
            cin >> num;
            auto w_i = workers.begin();
            advance(w_i, num);
            workers.erase(w_i);
            cout << endl;
            output_all(workers, 1);
            cout << endl;
            break;
        }
        case 5:
        {
            list<Worker> out;
            int year;
            cout << "Введите стаж:" << endl;
            cin >> year;
            out = search(workers, year);
            if (out.size() != 0)
                output_all(out, 1);
            else
                cout << "Рабочих с указанным стажем не обнаружено" << endl;
            cout << endl;
            break;
        }
        case 6:
        {
            list<Worker> out;
            string func;
            cout << "Введите должность:" << endl;
            cin >> func;
            out = search(workers, func);
            if(out.size() != 0)
                output_all(out, 1);
            else
                cout << "Рабочих с данной должностью не обнаружено" << endl;
            cout << endl;
            break;
        }
        case 7:
        {
            string n_file;
            cout << "Введите название файла сохранения" << endl;
            cin >> n_file;
            file_save(workers, n_file);
            cout << endl;
            break;
        }
        case 8:
        {
            if (workers.size() != 0)
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }
            Worker buf;
            int num;
            cout << "Выберите номер рабочего, чья запись будет изменена:" << endl;
            cin >> num;
            cout << endl;
            auto w_i = workers.begin();
            advance(w_i, num);
            cout << stand_out << *w_i << endl;
            cin >> buf;
            mod(workers, buf, num);
            cout << endl;
            output_all(workers, 1);
            cout << endl;
            break;
        }
        case 9:
        {
            if (workers.size() != 0)
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }
            int num;
            cout << "Выберите тип сортировки:" << endl;
            cout << "1. По фамилии." << endl;
            cout << "2. По стажу в годах." << endl;
            cin >> num;
            cout << endl;
            sort(workers, num);
            output_all(workers, 1);
            cout << endl;
            break;
        }
        case 10:
        {
            exit = true;
            break;
        }
        default:
            break;
        }
    }
}
