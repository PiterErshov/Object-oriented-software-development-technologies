#define _CRT_SECURE_NO_WARNINGS
#include "Worker.h"

using namespace Workers;

Worker::Worker()
{
	setS_name(string());
	setName(string());
	setPatr(string());
	this->day = 0;
	this->month = 0;
	this->year = 0;
}

Worker::Worker(string s_name, string name, string patronymic, string function, int day, int month, int year)
{
	setS_name(s_name);
	setName(name);
	setPatr(patronymic);
	setFunc(function);
	set_Date(day, month, year);
}

int Worker::checkDate(int day, int month, int year)
{
	struct tm* date;
	time_t t = time(NULL);
	date = gmtime(&t);

	if (day > 0)
	{
		if ((month == 1 || month == 3 || month == 5 || month == 7 ||
			month == 8 || month == 10 || month == 12) && day > 31)
			return 1;

		if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30)
			return 1;

		if (month == 2 && year % 4 == 0 && day > 29)
			return 1;

		if (month == 2 && year % 4 != 0 && day > 28)
			return 1;
	}
	else
		return 1;

	if (month < 0 || month > 12)
		return 2;

	if (year < 0 || year > date->tm_year + 1900)
		return 3;

	return 0;
}

void Worker::set_Date(int day, int month, int year)
{
	if (checkDate(day, month, year) == 0)
	{
		this->day = day;
		this->month = month;
		this->year = year;
	}	
}

void Worker::setS_name(string s_name)
{
	this->s_name = s_name;
}

void Worker::setName(string name)
{
	this->name = name;
}

void Worker::setPatr(string patronymic)
{
	this->patronymic = patronymic;
}

void Worker::setFunc(string function)
{
	this->function = function;
}



namespace Workers
{
	istream& operator>>(istream& in, Worker& input)
	{
		string s_name, name, part, func;
		int day, month, year;
		char open, close, point1, point2;
		bool flag = true;

		in >> s_name >> name >> part >> func >> open >> day >> point1 >> month >> point2 >> year >> close;

		Worker buf("0", "0", "0", "0", day, month, year);
		if (open != '(' || close != ')' || point1 != '.' || point2 != '.')
		{
			flag = false;
		}

		if (flag && buf.checkDate(day, month, year) == 0)
		{
			input.setS_name(s_name);
			input.setName(name);
			input.setPatr(part);
			input.setFunc(func);
			input.set_Date(day, month, year);
		}
		else
		{
			in.clear(ios::failbit);
			return in;
		}

		return in;
	}
}