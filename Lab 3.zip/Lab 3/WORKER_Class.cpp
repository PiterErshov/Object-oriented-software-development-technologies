﻿#include <iostream>
#include "Worker.h"
#include <fstream>
#include <vector>
#include <list>
#include <algorithm>
#include<unordered_set>
#include<set>

using namespace std;
using namespace Workers;

void file_load(unordered_set<Worker, c_hash, c_equal> & workers, string filename)
{
    Worker wr;
    ifstream f(filename);

    if (!f.is_open())
    {
        cout << "Error! No file with name " << filename << endl;
        return;
    }

    while (!f.eof())
    {
        f >> wr;
        if (f.fail())
        {
            f.clear(ios::eofbit);
            break;
        }
        workers.insert(wr);
    }
    f.close();
};


void file_save(unordered_set<Worker, c_hash, c_equal>& workers, string filename)
{
    Worker wr;
    ofstream f(filename);

    if (!f.is_open())
    {
        cout << "Error! No file with name " << filename << endl;
        return;
    }

    for (auto iter = workers.begin(); iter != workers.end(); iter++)
    {
        f << *iter << endl;
    }
    f.close();
};

void output_all(unordered_set<Worker, c_hash, c_equal>& workers, int format)
{
    int i = 0;
    for (auto iter = workers.begin(); iter != workers.end(); iter++)
    {
        if (format == 1)
            cout << stand_out << i << ". " << *iter << endl;
        else
            cout << tab_out << i << ". " << *iter << endl;
        i++;
    }
}

unordered_set<Worker, c_hash, c_equal> search(unordered_set<Worker, c_hash, c_equal>& workers, string function)
{
    unordered_set<Worker, c_hash, c_equal> out;
    unordered_set<Worker, c_hash, c_equal>::iterator iter;
    iter = find_if(workers.begin(),
        workers.end(), 
        [&](Worker w)
        {
            return w.getFunc() == function;
        });

    while (iter != workers.end())
    {
        out.insert(*iter);
        iter++;
        iter = find_if(iter, workers.end(), [&](Worker w)
            {
                return w.getFunc() == function;
            });
    }

    return out;
}

unordered_set<Worker, c_hash, c_equal> search(unordered_set<Worker, c_hash, c_equal> workers, int year)
{
    struct tm* date;
    time_t t = time(NULL);
    date = gmtime(&t);
    int tt = date->tm_year + 1900;
    unordered_set<Worker, c_hash, c_equal> out;
    unordered_set<Worker, c_hash, c_equal>::iterator iter;
    iter = find_if(workers.begin(),
        workers.end(),
        [&](Worker w)
        {
            return (tt - w.getYear()) > year;
        });


    while (iter != workers.end())
    {
        out.insert(*iter);
        iter++;
        iter = find_if(iter,
            workers.end(),
            [&](Worker w)
            {
                return (tt - w.getYear()) > year;
            });
    }

    return out;
};

set<Worker, Worker::sort_equal> sort(unordered_set<Worker, c_hash, c_equal> workers, int num)
{
    if (num == 1)
    {
        set<Worker, Worker::sort_equal> out(Worker::sort_equal{ true });

        for (auto iter = workers.begin(); iter != workers.end(); iter++)
            out.insert(*iter);
        return out;
    }
    if (num == 2)
    {
        set<Worker, Worker::sort_equal> out(Worker::sort_equal{ false });

        for (auto iter = workers.begin(); iter != workers.end(); iter++)
            out.insert(*iter);
        return out;
    }
}

void mod(unordered_set<Worker, c_hash, c_equal>& workers, Worker buf, int num)
{
    auto w_i = workers.begin();
    advance(w_i, num);
    workers.erase(w_i);
    buf.setS_name(buf.getS_name());
    buf.setName(buf.getName());
    buf.setPatr(buf.getPatr());
    buf.setFunc(buf.getFunc());
    buf.set_Date(buf.getDay(), buf.getMonth(), buf.getYear());
    workers.insert(buf);
};

void printHashTableState(unordered_set<Worker, c_hash, c_equal>& cont)
{
    // основные данные о структуре
    cout << "size: " << cont.size() << endl;
    cout << "buckets: " << cont.bucket_count() << endl;
    cout << "load factor: " << cont.load_factor() << endl;
    cout << "max load factor: " << cont.max_load_factor() << endl;
    // элементы в сегментах
    cout << "data: " << endl;
    for (int idx = 0; idx != cont.bucket_count(); ++idx) if (cont.bucket_size(idx) > 0) {
        cout << " b[" << idx << "]: ";
        for (auto pos = cont.begin(idx); pos != cont.end(idx); ++pos)
            cout << *pos << " ";
        cout << endl;
    }
    cout << endl;
}

int main()
{
    setlocale(LC_ALL, "Russian");
    
    bool exit = false;
    int option;
   
    //*
    unordered_set<Worker, c_hash, c_equal> workers;

    while (!exit)
    {
        cout << "Выберете функцию:" << endl;
        cout << "1. Вывод списка рабочих." << endl;
        cout << "2. Добавление нового рабочего." << endl;
        cout << "3. Добавление рабочих из файла." << endl;
        cout << "4. Удаление рабочих." << endl;
        cout << "5. Поиск рабочих, чей стаж превышает заданное значение." << endl;
        cout << "6. Поиск рабочих по конкретной должности." << endl;
        cout << "7. Сохранение списка рабочих в указанный файл." << endl;
        cout << "8. Модификация указанной записи рабочего." << endl;
        cout << "9. Сортировка списка." << endl;
        cout << "10. Сортировка списка." << endl;
        cout << "11. Выход." << endl;

        cin >> option;

        while (cin.fail())
        {
            cin.clear();
            cout << "Не верное значение!" << endl;
            cin.ignore();
            cin >> option;
        }

        switch (option)
        {
        case 1:
        {
            int format;
            cout << "Выберите формат вывода:" << endl;
            cout << "1. Стандартный в строку." << endl;
            cout << "2. В формате таблицы." << endl;
            cin >> format;            
            if (!workers.empty())
                output_all(workers, format);
            else
                cout << "Список рабочих пуст" << endl;
            cout << endl;
            break;
        }
        case 2:
        {
            Worker buf;
            cout << "Введите данные нового рабочего в формате: Фамилия Имя Отчество Должность (0.0.0000)" << endl;
            cin >> buf;
           
                workers.insert(buf);
            cout << endl;
            break;
        }
        case 3:
        {
            file_load(workers, "data.txt");
            cout << endl;
            break;
        }
        case 4:
        {
            if (!workers.empty())
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }

            int num;
            cout << "Выберите номер рабочего, чья запись будет удалена:" << endl;
            cin >> num;
            auto w_i = workers.begin();
            advance(w_i, num);
            workers.erase(w_i);
            cout << endl;
            output_all(workers, 1);
            cout << endl;
            break;
        }
        case 5:
        {
            unordered_set<Worker, c_hash, c_equal> out;
            int year;
            cout << "Введите стаж:" << endl;
            cin >> year;
            out = search(workers, year);
            if (out.size() != 0)
                output_all(out, 1);
            else
                cout << "Рабочих с указанным стажем не обнаружено" << endl;
            cout << endl;
            break;
        }
        case 6:
        {
            unordered_set<Worker, c_hash, c_equal> out;
            string func;
            cout << "Введите должность:" << endl;
            cin >> func;
            out = search(workers, func);
            if(out.size() != 0)
                output_all(out, 1);
            else
                cout << "Рабочих с данной должностью не обнаружено" << endl;
            cout << endl;
            break;
        }
        case 7:
        {
            string n_file;
            cout << "Введите название файла сохранения" << endl;
            cin >> n_file;
            file_save(workers, n_file);
            cout << endl;
            break;
        }
        case 8:
        {
            if (workers.size() != 0)
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }
            Worker buf;
            int num;
            cout << "Выберите номер рабочего, чья запись будет изменена:" << endl;
            cin >> num;
            cout << endl;
            auto w_i = workers.begin();
            advance(w_i, num);
            cout << stand_out << *w_i << endl;
            cin >> buf;
            mod(workers, buf, num);
            cout << endl;
            output_all(workers, 1);
            cout << endl;
            break;
        }
        case 9:
        {
            if (workers.size() != 0)
                output_all(workers, 1);
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }
            set<Worker, Worker::sort_equal> sort_w;
            int num;
            cout << "Выберите тип сортировки:" << endl;
            cout << "1. По фамилии." << endl;
            cout << "2. По стажу в годах." << endl;
            cin >> num;
            cout << endl;
            sort_w = sort(workers, num);

            int i = 0;
            for (auto iter = sort_w.begin(); iter != sort_w.end(); iter++)
            {
                cout << stand_out << i << ". " << *iter << endl;
                i++;
            }
            cout << endl;
            break;
        }
        case 10:
        {
            if (workers.size() != 0)
            {
                printHashTableState(workers);
                cout << "Добавим новые данные в список рабочих" << endl;
                file_load(workers, "new_data.txt");
                cout << endl;
                printHashTableState(workers);
            }
            else
            {
                cout << "Список рабочих пуст" << endl;
                break;
            }
            
            break;
        }
        case 11:
        {
            exit = true;
            break;
        }
        default:
            break;
        }
    }
}
