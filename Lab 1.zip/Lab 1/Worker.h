#ifndef WORKER
#define WORKER

#pragma once
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <ctime>

using namespace std;

namespace Workers
{
	const int spec_index = ios_base::xalloc();

	template <typename charT, typename traits>inline basic_ostream <charT, traits>&
		tab_out(basic_ostream<charT, traits>& out)
	{
		out.iword(spec_index) = true;
		return out;
	}

	template <typename charT, typename traits> inline basic_ostream<charT, traits>&
		stand_out(basic_ostream<charT, traits>& out)
	{
		out.iword(spec_index) = false;
		return out;
	}


	class Worker
	{
		private:
			string s_name = "",
				name = "",
				patronymic = "",
				function = "";

			int day,
				month,
				year;

		public:

			Worker();

			Worker(string s_name, string name, string patronymic, string function, int day, int month, int year);
		
			int checkDate(int day, int month, int year);
			


			void set_Date(int day, int month, int year);

			void setS_name(string s_name);

			void setName(string name);

			void setPatr(string patronymic);

			void setFunc(string function);

			template <typename charT, typename traits> friend basic_ostream<charT, traits>&
				operator << (basic_ostream<charT, traits>& out, const Worker& c);

			friend istream& operator>>(istream& in, Worker& c);

			string getS_name()
			{
				return this->s_name;
			}

			string getName()
			{
				return this->name;
			}

			string getPatr()
			{
				return this->patronymic;
			}

			string getFunc()
			{
				return this->function;
			}

			int getDay()
			{
				return this->day;
			}

			int getMonth()
			{
				return this->month;
			}

			int getYear()
			{
				return this->year;
			}
			

	};

	template <typename charT, typename traits> 
	inline basic_ostream<charT, traits>& operator << (basic_ostream<charT, traits>& out, const Worker& c)
	{
		basic_ostringstream <charT, traits> s;

		s.copyfmt(out);
		s.width(0);
			
		if (s.iword(spec_index)) {
			s << "Second name: " << c.s_name << endl;
			s << "Name: " << c.name << endl;
			s << "Patronymic: " << c.patronymic << endl;
			s << "Position: " << c.function << endl;
			s << "Beginning of work: " << c.day << "." << c.month << "." << c.year << endl;
		}
		else
			s << c.s_name << " " << c.name << " " << c.patronymic << " " << c.function << " (" << c.day << "." << c.month << "." << c.year << ")";
		out << s.str();
		return out;
	}

}
#endif