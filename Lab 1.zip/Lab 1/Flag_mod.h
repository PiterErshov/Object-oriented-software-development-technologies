#ifndef FLAG_MOD
#define FLAG_MOD

#pragma once
#include <iostream>
#include <string>
#include "Worker.h"

using namespace std;


#endif